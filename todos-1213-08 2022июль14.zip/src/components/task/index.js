import Task from "./task";

export default Task;
